const fs = require('fs'),
  vm = require('vm'),
  crypto = require('crypto'),
  assert = require('assert'),
  path = require('path');
const root = path.resolve(__dirname, '..'),
  html = fs.readFileSync(path.join(root, 'public-output/Kaizo_Baconmon_Patcher.html'), 'utf8'),
  script = html.match(/<script>([\s\S]*)<\/script>/)[1],
  ctx = vm.createContext({
    crypto: crypto.webcrypto,
    DecompressionStream,
    Response,
    Blob,
    atob,
    Uint8Array,
    Uint32Array,
    DataView,
    Array,
    TextEncoder,
    Error,
    Math,
  });
vm.runInContext(
  script + ';globalThis.M=CONFIG;globalThis.pool=()=>LegacyCore.inflate(PAYLOAD);',
  ctx,
);
(async () => {
  const C = new Uint8Array(
      fs.readFileSync(path.join(root, 'patch-inputs/Pokemon - Fire Red Version (U) (V1.1).gba')),
    ),
    p = await ctx.pool(),
    api = ctx.BaconPublic,
    M = ctx.M,
    checks = [];
  for (const f of M.core_features) {
    const r = await api.patchROM(C, [f.id], p);
    assert(
      !r.report.features.some((x) => x.status === 'skipped'),
      JSON.stringify(r.report.features),
    );
    for (const at of [0x55080, 0x6a418])
      assert.deepEqual(Array.from(r.rom.slice(at, at + 8)), Array.from(C.slice(at, at + 8)));
    fs.writeFileSync(path.join(root, 'public-patcher', f.id + '_without_faster.gba'), r.rom);
    checks.push(f.id);
  }
  const all = M.groups.map((g) => g.id),
    full = await api.patchROM(C, all, p),
    off = await api.patchROM(
      full.rom,
      all.filter((x) => x !== 'faster'),
      p,
    );
  assert(
    off.report.features.filter((x) => x.status === 'skipped').every((x) => x.id === 'text'),
    JSON.stringify(off.report.features),
  );
  for (const at of [0x55080, 0x6a418])
    assert.deepEqual(Array.from(off.rom.slice(at, at + 8)), Array.from(C.slice(at, at + 8)));
  const nurse = await api.patchROM(C, ['nurse'], p);
  assert.equal(nurse.report.features.find((x) => x.id === 'nurse').status, 'applied');
  fs.writeFileSync(path.join(root, 'public-patcher/nurse_without_faster.gba'), nurse.rom);
  fs.writeFileSync(path.join(root, 'public-patcher/all_without_faster.gba'), off.rom);
  fs.writeFileSync(
    path.join(root, 'public-output/Faster_Separation_Tests.json'),
    JSON.stringify(
      {
        independent_features: checks,
        original_speed_hooks_preserved: true,
        existing_faster_build_can_be_disabled: true,
        incompatible_dialogue_script_skipped: off.report.features.some(
          (x) => x.id === 'text' && x.status === 'skipped',
        ),
        forest_nurse_independent: true,
        scope:
          'ROM guards and speed-hook bytes. Runtime and emulator checks are reported separately.',
      },
      null,
      2,
    ),
  );
  console.log(
    'PASS all core features and nurse without Faster; disabling existing Faster preserves selected extras.',
  );
})().catch((e) => {
  console.error(e);
  process.exit(1);
});

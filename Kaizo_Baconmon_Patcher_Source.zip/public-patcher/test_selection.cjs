const fs = require('fs'),
  vm = require('vm'),
  crypto = require('crypto'),
  assert = require('assert'),
  path = require('path');
const root = path.resolve(__dirname, '..'),
  html = fs.readFileSync(path.join(root, 'public-output/Kaizo_Baconmon_Patcher.html'), 'utf8'),
  script = html.match(/<script>([\s\S]*)<\/script>/)[1],
  ids = [
    'status',
    'faster',
    'title',
    'tunnel',
    'hidden',
    'nurse',
    'text',
    'rival',
    'modern',
    'lab',
    'rotation',
    'hms',
    'friendship',
    'guide',
    'battleinfo',
    'relearner',
  ];
function setup() {
  const nodes = {},
    blobs = new Map();
  let n = 0;
  for (const id of [
    'package',
    'tutor',
    'rivalLevel',
    'run',
    'file',
    'downloads',
    'status',
    'report',
    ...ids.filter((x) => x !== 'relearner').map((x) => 'feature-' + x),
  ])
    nodes[id] = {
      checked: true,
      value: id.replace('feature-', ''),
      disabled: false,
      children: [],
      files: [],
      appendChild(x) {
        this.children.push(x);
      },
      replaceChildren() {
        this.children = [];
      },
    };
  nodes.rivalLevel.value = '8';
  nodes.tutor.value = 'relearner';
  const source = fs.readFileSync(
    path.join(root, 'patch-inputs/Pokemon - Fire Red Version (U) (V1.1).gba'),
  );
  nodes.file.files = [
    { name: 'Test.gba', arrayBuffer: async () => Uint8Array.from(source).buffer },
  ];
  const document = {
    getElementById: (id) => nodes[id],
    querySelectorAll: () =>
      ids.map((x) => nodes[x === 'relearner' ? 'tutor' : 'feature-' + x]).filter((x) => x.checked),
    createElement: () => ({}),
  };
  const ctx = vm.createContext({
    crypto: crypto.webcrypto,
    DecompressionStream,
    Response,
    Blob,
    atob,
    Uint8Array,
    Uint32Array,
    DataView,
    Array,
    TextEncoder,
    Error,
    Math,
    document,
    setTimeout,
    URL: {
      createObjectURL: (b) => {
        let k = 'blob:' + n++;
        blobs.set(k, b);
        return k;
      },
      revokeObjectURL: (k) => blobs.delete(k),
    },
  });
  vm.runInContext(script + '\nglobalThis.M=CONFIG;', ctx);
  return { nodes, blobs, ctx, source };
}
function toggle(t, id, checked) {
  const x = t.nodes[id];
  x.checked = checked;
  x.onchange();
}
async function output(t) {
  await t.nodes.run.onclick();
  const node = t.nodes.downloads.children.find((x) => x.textContent === 'Patched ROM');
  assert(node, t.nodes.status.textContent);
  return new Uint8Array(await t.blobs.get(node.href).arrayBuffer());
}
(async () => {
  const t = setup();
  assert(t.nodes.package.checked);
  toggle(t, 'feature-title', false);
  assert(!t.nodes.package.checked && t.nodes.package.indeterminate);
  toggle(t, 'feature-modern', false);
  assert(t.nodes['feature-guide'].checked && t.nodes.tutor.checked);
  toggle(t, 'feature-faster', false);
  assert(t.nodes['feature-guide'].checked && t.nodes.tutor.checked);
  toggle(t, 'feature-guide', true);
  assert(!t.nodes['feature-faster'].checked && !t.nodes['feature-modern'].checked);
  toggle(t, 'package', false);
  assert(ids.every((id) => !t.nodes[id === 'relearner' ? 'tutor' : 'feature-' + id].checked));
  assert(t.nodes.rivalLevel.disabled);
  toggle(t, 'feature-rival', true);
  t.nodes.rivalLevel.value = '100';
  const rival = await output(t);
  fs.writeFileSync(path.join(root, 'public-patcher/rival-100.gba'), rival);
  for (const id of [326, 327, 328]) {
    const p =
      new DataView(rival.buffer).getUint32(t.ctx.M.trainer_table + id * 40 + 36, true) - 0x8000000;
    assert.equal(rival[p + 2], 100);
  }
  const h = t.ctx.M.rival_normalizer;
  assert.deepEqual(Array.from(rival.slice(h.offset, h.offset + h.off.length)), Array.from(h.off));
  toggle(t, 'package', true);
  assert(ids.every((id) => t.nodes[id === 'relearner' ? 'tutor' : 'feature-' + id].checked));
  t.nodes.tutor.checked = false;
  t.nodes.tutor.onchange();
  assert(t.nodes.package.indeterminate);
  t.nodes.rivalLevel.value = '1';
  const custom = await output(t);
  fs.writeFileSync(path.join(root, 'public-patcher/rival-1.gba'), custom);
  assert.equal(custom[0x3bc4e4], 1);
  assert.deepEqual(Array.from(custom.slice(h.offset, h.offset + h.off.length)), Array.from(h.off));
  t.nodes.rivalLevel.value = '1.5';
  await t.nodes.run.onclick();
  assert.match(t.nodes.status.textContent, /whole number/);
  assert.equal(t.nodes.downloads.children.length, 0);
  for (const title of [
    'About this patcher',
    'What is Kaizo Baconmon?',
    'Full Kaizo Baconmon rule list',
    'Nuz-guide key item and point tracking',
    'On PC',
    'On Android, without a PC',
  ])
    assert(html.includes('<summary>' + title + '</summary>'));
  const report = {
    select_all_and_partial_selection: true,
    faster_extras_independent: true,
    rival_only_without_core: true,
    custom_level_disables_level_8_runtime_override: true,
    tutor_off_with_custom_level: true,
    invalid_level_blocks_downloads: true,
    help_sections_present: true,
    scope: 'Actual HTML JavaScript with DOM stubs; no rendered browser or Android hardware test.',
  };
  fs.writeFileSync(
    path.join(root, 'public-output/Selection_Tests.json'),
    JSON.stringify(report, null, 2),
  );
  console.log(
    'PASS selection controls, dependencies, custom-level runtime hook, help sections and invalid input.',
  );
})().catch((e) => {
  console.error(e);
  process.exit(1);
});

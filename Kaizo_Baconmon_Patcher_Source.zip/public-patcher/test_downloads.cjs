const fs = require('fs'),
  vm = require('vm'),
  crypto = require('crypto'),
  assert = require('assert'),
  path = require('path');
const root = path.resolve(__dirname, '..'),
  sha = (b) => crypto.createHash('sha256').update(b).digest('hex');
async function test(kind, file, input) {
  const html = fs.readFileSync(path.join(root, 'public-output', file), 'utf8'),
    script = html.match(/<script>([\s\S]*)<\/script>/)[1],
    nodes = {},
    blobs = new Map();
  let n = 0;
  for (const id of ['run', 'status', 'downloads', 'report', 'file'])
    nodes[id] = {
      files: [],
      children: [],
      disabled: false,
      hidden: false,
      appendChild(x) {
        this.children.push(x);
      },
      replaceChildren() {
        this.children = [];
      },
      remove() {},
    };
  nodes.tutor = { checked: true };
  nodes.rivalLevel = { value: '8' };
  const source =
    kind === 'unknown' ? Buffer.alloc(0x1000000) : fs.readFileSync(path.join(root, input));
  if (kind === 'unknown') source.write('BPEE', 0xac);
  nodes.file.files = [
    {
      name: 'My_Run.gba',
      arrayBuffer: async () =>
        source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength),
    },
  ];
  const document = {
    getElementById: (id) => nodes[id],
    querySelectorAll: () =>
      [
        'status',
        'faster',
        'title',
        'tunnel',
        'hidden',
        'nurse',
        'text',
        'rival',
        'modern',
        'lab',
        'rotation',
        'hms',
        'friendship',
        'guide',
        'battleinfo',
        'relearner',
      ].map((value) => ({ value })),
    createElement: (tag) => ({ tagName: tag, remove() {} }),
  };
  const ctx = vm.createContext({
    crypto: crypto.webcrypto,
    DecompressionStream,
    Response,
    Blob,
    atob,
    Uint8Array,
    Uint32Array,
    DataView,
    Array,
    TextEncoder,
    Error,
    Math,
    document,
    setTimeout,
    URL: {
      createObjectURL: (b) => {
        const k = 'blob:' + n++;
        blobs.set(k, b);
        return k;
      },
      revokeObjectURL: (k) => blobs.delete(k),
    },
  });
  vm.runInContext(script, ctx);
  await nodes.run.onclick();
  assert.match(nodes.status.textContent, kind === 'unknown' ? /No changes made/ : /Done/);
  assert.equal(nodes.run.disabled, false);
  const get = (label) => nodes.downloads.children.find((x) => x.textContent === label),
    result = get('Patched ROM');
  if (kind === 'unknown') assert(!result);
  else assert(result);
  const out = result ? Buffer.from(await blobs.get(result.href).arrayBuffer()) : source;
  const notes = get('Patch notes');
  assert(notes);
  const text = await blobs.get(notes.href).text();
  assert(text.includes('\n'));
  assert(!text.includes('\\n'));
  assert(text.includes('xbaconator9000x'));
  if (kind === 'unknown') {
    assert(get('Detailed report'));
    assert(text.includes('SKIPPED') && text.includes('NOTICES'));
    assert.equal(nodes.downloads.children.length, 2);
  }
  if (kind === 'rom') {
    assert(get('BPS patch') && get('Undo patch') && get('Detailed report'));
    assert(text.includes('Classic / Modern'));
    assert.equal(
      sha(out),
      sha(fs.readFileSync(path.join(root, 'public-patcher/emulator-input.gba'))),
    );
  }

  return {
    kind,
    download_sha256: sha(out),
    notes_have_real_line_breaks: true,
    downloads_created: true,
  };
}
(async () => {
  const report = {
    tests: [
      await test(
        'rom',
        'Kaizo_Baconmon_Patcher.html',
        'patch-inputs/Pokemon - Fire Red Version (U) (V1.1).gba',
      ),
      await test('unknown', 'Kaizo_Baconmon_Patcher.html'),
    ],
    scope:
      'Actual HTML event handlers and Blob downloads with DOM stubs. No rendered browser or Android installation test.',
  };
  fs.writeFileSync(
    path.join(root, 'public-output/Download_Tests.json'),
    JSON.stringify(report, null, 2),
  );
  console.log('PASS: ROM downloads and unknown-layout notes/report without rejection.');
})().catch((e) => {
  console.error(e);
  process.exit(1);
});

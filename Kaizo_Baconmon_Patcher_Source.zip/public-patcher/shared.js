function portableSha256(bytes) {
  const constants = [0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  const state = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
  const length = Math.ceil((bytes.length + 9) / 64) * 64, padded = new Uint8Array(length), words = new Uint32Array(64);
  padded.set(bytes); padded[bytes.length] = 128;
  const view = new DataView(padded.buffer); view.setUint32(length - 8, Math.floor(bytes.length / 0x20000000)); view.setUint32(length - 4, (bytes.length * 8) >>> 0);
  const rotate = (x,n) => (x >>> n) | (x << (32 - n));
  for (let offset = 0; offset < length; offset += 64) {
    for (let i = 0; i < 16; i++) words[i] = view.getUint32(offset + i * 4);
    for (let i = 16; i < 64; i++) { const x = words[i-15], y = words[i-2]; words[i] = (words[i-16] + (rotate(x,7)^rotate(x,18)^(x>>>3)) + words[i-7] + (rotate(y,17)^rotate(y,19)^(y>>>10))) >>> 0; }
    let [a,b,c,d,e,f,g,h] = state;
    for (let i = 0; i < 64; i++) {
      const t1 = (h + (rotate(e,6)^rotate(e,11)^rotate(e,25)) + ((e&f)^(~e&g)) + constants[i] + words[i]) >>> 0;
      const t2 = ((rotate(a,2)^rotate(a,13)^rotate(a,22)) + ((a&b)^(a&c)^(b&c))) >>> 0;
      h=g;g=f;f=e;e=(d+t1)>>>0;d=c;c=b;b=a;a=(t1+t2)>>>0;
    }
    [a,b,c,d,e,f,g,h].forEach((v,i)=>{state[i]=(state[i]+v)>>>0;});
  }
  return Array.from(state,x=>x.toString(16).padStart(8,'0')).join('');
}
const LegacyCore = {
  async hash(bytes) {
    if (!globalThis.crypto?.subtle) return portableSha256(bytes);
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest), x => x.toString(16).padStart(2, '0')).join('');
  },
  async inflate(text) {
    if (typeof DecompressionStream === 'undefined') throw Error('This browser cannot unpack the update. Open the patcher in a current browser, or use the supplied BPS patch with a BPS patching tool.');
    const binary = atob(text), compressed = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) compressed[i] = binary.charCodeAt(i);
    return new Uint8Array(await new Response(new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate'))).arrayBuffer());
  },
  identify(hash, manifest = MANIFEST) {
    const latest = manifest.latest.find(x => x.sha256 === hash);
    if (latest) return { latest };
    const route = manifest.routes.find(x => x.input_sha256 === hash);
    if (!route) throw Error('This file is not one of the supported versions. Nothing has been changed. Check the supported files below. An arbitrary randomized ROM or a different APK release cannot use these patches.');
    return { route };
  },
  async apply(source, route, pool, manifest = MANIFEST) {
    if (source.length !== route.input_bytes || await this.hash(source) !== route.input_sha256) throw Error('Input verification failed. Nothing has been changed.');
    const output = new Uint8Array(route.output_bytes);
    let at = 0;
    for (const cmd of route.commands) {
      let bytes;
      if (cmd[0] === 0) {
        if (cmd[1] < 0 || cmd[2] < 1 || cmd[1] + cmd[2] > source.length) throw Error('Invalid source copy in patch.');
        bytes = source.subarray(cmd[1], cmd[1] + cmd[2]);
      } else if (cmd[0] === 1) {
        const entry = manifest.pool[cmd[1]];
        if (!entry || entry[0] < 0 || entry[1] < 1 || entry[0] + entry[1] > pool.length) throw Error('Invalid data in patch.');
        bytes = pool.subarray(entry[0], entry[0] + entry[1]);
      } else throw Error('Unknown patch command.');
      if (at + bytes.length > output.length) throw Error('Patch exceeds expected output size.');
      output.set(bytes, at); at += bytes.length;
    }
    if (at !== output.length || await this.hash(output) !== route.output_sha256) throw Error('The updated file failed verification. No download was created.');
    return output;
  }
};

